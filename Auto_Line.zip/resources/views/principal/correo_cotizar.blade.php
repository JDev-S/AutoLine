<h2>Nombre Completo: {{$nombre}} {{$paterno}} {{$materno}}</h2>
<h2>Email: {{$correo}}</h2>
<h2>Télefono: {{$telefono}}</h2>
<h2>Nombre del auto:{{$auto}}</h2>
<h2>Precio del auto:{{$precio}}</h2>
