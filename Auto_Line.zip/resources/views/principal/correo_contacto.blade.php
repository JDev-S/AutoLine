<h2>Nombre Completo: {{$nombre_completo}}</h2>
<h2>Email: {{$email}}</h2>
<h2>Télefono: {{$telefono}}</h2>
<h2>Descripción: {{$descripcion}}</h2>
