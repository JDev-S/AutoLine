<h2>Nombre Completo: <?php echo e($nombre_completo); ?></h2>
<h2>Email: <?php echo e($email); ?></h2>
<h2>Télefono: <?php echo e($telefono); ?></h2>
<h2>Descripción: <?php echo e($descripcion); ?></h2>
<?php /**PATH C:\xampp\htdocs\Auto_Line\Auto_Line\resources\views//principal/correo_contacto.blade.php ENDPATH**/ ?>