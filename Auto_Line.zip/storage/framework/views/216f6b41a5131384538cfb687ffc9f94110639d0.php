 
<!DOCTYPE html>
<html lang="en">
<head>


<!-- Favicon -->
<link rel="shortcut icon" href="images/favicon.ico" />

<!-- bootstrap -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />

<!-- flaticon -->
<link rel="stylesheet" type="text/css" href="css/flaticon.css" />

<!-- mega menu -->
<link rel="stylesheet" type="text/css" href="css/mega-menu/mega_menu.css" />

<!-- mega menu -->
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />

<!-- main style -->
<link rel="stylesheet" type="text/css" href="css/style.css" />

<!-- responsive -->
<link rel="stylesheet" type="text/css" href="css/responsive.css">

<!-- Style customizer -->
<link rel="stylesheet" href="#" data-style="styles">
<link rel="stylesheet" type="text/css" href="css/style-customizer.css" />


</head>

<body>
<section class="error-page page-section-ptb">
  <div class="container">
    <div class="row">
     <div class="col-md-12">
        <div class="error-content text-center">
          <h2>404</h2>
          <img class="img-fluid center-block" src="/images/404_error.png" alt="404_error">
           
          <h3 class="text-red">Ooopps:( </h3>
          <strong class="text-black"> La pàgina que estas buscando no pudo ser encontrada</strong>
          <p>No pudiste encontrar lo que estabas buscando? Tomate un momento y empieza desde nuestro <a href="/"> Inicio </a></p>
        </div>             
      </div>
     </div>
   </div>
</section>

<!--=================================
 error -->
 
 
<!--=================================
 footer -->


  
</body>
</html>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Auto_Line\Auto_Line\vendor\laravel\framework\src\Illuminate\Foundation\Exceptions/views/404.blade.php ENDPATH**/ ?>