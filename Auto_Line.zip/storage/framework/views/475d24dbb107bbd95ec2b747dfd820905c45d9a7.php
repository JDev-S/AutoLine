<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Player - Live 🔴</title>

    <link href="https://vjs.zencdn.net/7.5.4/video-js.css" rel="stylesheet">
    <script src='https://vjs.zencdn.net/7.5.4/video.js'></script>
</head>
<body>
    <video id="player" class="video-js vjs-default-skin" width="800" height="440"  controls preload="none">
        <source src="http://192.168.0.6:8080/livestream/stream.m3u8" type="application/x-mpegURL" />
    </video>  
    <script>
        var player = videojs('#player')
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Auto_Line\Auto_Line\resources\views//principal/livestream.blade.php ENDPATH**/ ?>