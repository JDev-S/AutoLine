

<?php $__env->startSection('contenido'); ?>
<?php $__env->startSection('styles'); ?>
<style>
/*Switch Styles*/
.noneDysplay{
    display: none;
}    
    
.toggle{
  position: relative;
  display: block;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  transform: translate3d(0,0,0);
}
.toggle:before{
    content: "";
    position: relative;
    top: 3px;
    left: 3px;
    width: 44px;
    height: 21px;
    display: block;
    background: #dbdbdb;
    border-radius: 15px;
    transition: background .2s ease;
}
.toggle span{
    position: absolute;
    top: 0;
    left: 0;
    width: 26px;
    height: 26px;
    display: block;
    background: white;
    border-radius: 20px;
    box-shadow: 0 3px 8px #dbdbdb;
    transition: all .2s ease;
}
.toggle span:before{
      content: "";
      position: absolute;
      display: block;
      margin: -18px;
      width: 56px;
      height: 56px;
      background: #0072CE;
      border-radius: 50%;
      transform: scale(0);
      opacity: 1;
      pointer-events: none;
}
#ingresos:checked + .toggle:before{
    background: #0072CE;
}
#ingresos:checked + .toggle span{
    background: #ffffff;
    transform: translateX(25px);
    transition: all 0.4s cubic-bezier(.8,.4,.3,1.25), background .15s ease;
    box-shadow: 0 3px 8px rgba(0,0,0,0.3);
}
#historial:checked + .toggle:before{
    background: #0072CE;
}
#historial:checked + .toggle span{
    background: #ffffff;
    transform: translateX(25px);
    transition: all 0.4s cubic-bezier(.8,.4,.3,1.25), background .15s ease;
    box-shadow: 0 3px 8px rgba(0,0,0,0.3);
}

/*Switch Styles*/
</style>
<?php $__env->stopSection(); ?>


<div id="rev_slider_3_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="car-dealer-05" data-source="gallery" style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
<!-- START REVOLUTION SLIDER 5.3.0.2 fullwidth mode -->
  <div id="rev_slider_3_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.3.0.2">
<ul>  <!-- SLIDE  -->
    
    <li data-index="rs-3" data-transition="random-static,random-premium,random" data-slotamount="default,default,default,default" data-hideafterloop="0" data-hideslideonmobile="off"  data-randomtransition="on" data-easein="default,default,default,default" data-easeout="default,default,default,default" data-masterspeed="default,default,default,default"  data-thumb=""  data-rotate="0,0,0,0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
    <!-- MAIN IMAGE -->
         <?php $__currentLoopData = $oAutos->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img src='<?php echo e($auto->foto); ?>'  alt="imagen_auto"  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- LAYERS -->

  </li>
    
</ul>
<div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div> </div>
</div>

<section class="car-details page-section-ptb">

  <div class="container">
    <div class="row">
     <div class="col-md-9">
       <h3><?php echo e($oAutos->nombre); ?></h3>
      </div>
     <div class="col-md-3">
      <div class="car-price text-lg-right">
         <strong><?php echo e($oAutos->precio); ?></strong>
       </div> 
      </div> 
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="details-nav">
            <ul>
              
              <li><a href="javascript:window.print()"><i class="fa fa-print"></i>Imprime esta página</a></li>
            </ul>
         </div>
      </div>
    </div>
    <div class="row">
     <div class="col-md-8">
        <div class="slider-slick">
          <div class="slider slider-for detail-big-car-gallery">
              <?php $__currentLoopData = $oAutos->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img class="img-fluid" src='<?php echo e($auto->foto); ?>' alt="imagen_auto">
                
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="slider slider-nav"> 
              <?php $__currentLoopData = $oAutos->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img class="img-fluid" src='<?php echo e($auto->foto); ?>' alt="imagen_auto">
                
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         </div>
        <div id="tabs">
          

         <div id="tab2" class="tabcontent"> 
            <h6>ESPECIFICACIONES</h6>   
              <table class="table table-bordered">
                 
                <tbody>
                    <?php $__currentLoopData = $oAutos->especificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"> <?php echo e($auto->especificacion); ?></th>
                    <td><?php echo e($auto->descripcion); ?></td>
                  </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                  
                  
                </tbody>
              </table>
         </div>
      </div>

  <div class="feature-car">
   <h6>Vehiculos recientes</h6>
    <div class="row">
     <div class="col-md-12">
         <?php 
      
      if ($numero >=3) {
     echo'<div class="owl-carousel" data-nav-arrow="true" data-nav-dots="true" data-items="3" data-md-items="3" data-sm-items="2" data-space="15">';
}  else {
     echo'<div class="owl-carousel" data-nav-arrow="true" data-nav-dots="true" data-items="'.$numero.'" data-md-items="'.$numero.'" data-sm-items="2" data-space="15">';
}
 ?>
          <?php $__currentLoopData = $aAutos2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item">
         <div class="car-item gray-bg text-center">
           <div class="car-image">
             <img class="img-fluid" src='<?php echo e($auto->foto); ?>' alt="">
             <div class="car-overlay-banner">

             </div>
           </div>
           <div class="car-list">
             <ul class="list-inline">
               <li><i class="fa fa-calendar"></i><?php echo e($auto->anio); ?></li>
               <li><i class="fa fa-car"></i><?php echo e($auto->transmision); ?></li>
               <li><i class="fa fa-dashboard"></i><?php echo e($auto->kilometraje); ?></li>
             </ul>
          </div>
           <div class="car-content">
             <a href='/vehiculo/<?php echo e($auto->id_auto); ?>'><?php echo e($auto->nombre); ?></a>
             <div class="separator"></div>
             <div class="price">
               
               <span class="new-price"><?php echo e($auto->precio); ?> </span>
             </div>
           </div>
         </div>
       </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
      </div>
     </div>
    </div>
   </div>
   <div class="col-md-4">
       <div class="car-details-sidebar">
          <div class="details-social details-weight">
            <h5>Compartir ahora</h5>
            <ul>
              <li><a href="https://www.facebook.com/autolinesalamanca/"> <i class="fa fa-facebook"></i> facebook</a></li>
              <li><a href="https://www.instagram.com/autolinegto/?hl=es-la"> <i class="fa fa-instagram"></i> Instagram</a></li>
              <li><a href="#"> <i class="fa fa-pinterest-p"></i> pinterest</a></li>
              <li><a href="#"> <i class="fa fa-dribbble"></i> dribbble</a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i> google plus </a></li>
              <li><a href="#"> <i class="fa fa-behance"></i> behance</a></li>
            </ul>
            </div>
            <div class="details-form contact-2 details-weight">
               <form class="gray-form" method="POST" action=<?php echo e(route('cotizar')); ?>>
            <?php echo e(csrf_field()); ?>

                <h5>Realizar cotización</h5>
                <div class="form-group">
                    <input id="id_auto" name="id_auto" type="hidden" value='<?php echo e($oAutos->id_auto); ?>'>
                    <input id="auto" name="auto" type="hidden" value='<?php echo e($oAutos->nombre); ?>'>
                    <input id="precio" name="precio" type="hidden" value='<?php echo e($oAutos->precio2); ?>'>  
                </div>
                   
                   <div class="form-group">
                   <label>Nombre(s)*</label>
                   <input type="text" class="form-control"  id="nombre" name="nombre" required>
                </div>
                   
                   <div class="form-group">
                   <label>Primer apellido*</label>
                   <input type="text" class="form-control"  id="paterno" name="paterno" required>
                </div>
                   
                   <div class="form-group">
                   <label>Segundo apellido*</label>
                   <input type="text" class="form-control"  id="materno" name="materno" required>
                </div>
                   
                   
                 <div class="form-group">
                    <label>Correo*</label>
                    <input type="email" class="form-control"  id="correo" name="correo" required>
                </div>
                 <div class="form-group">
                    <label>Teléfono*</label>
                    <input type="text" class="form-control"  id="telefono" name="telefono" required>
                </div>
                <div class="form-group">
                    <label>Costo del auto*</label>
                   
                    <input type="text" class="form-control" disabled  value='<?php echo e($oAutos->precio); ?>'  id="precio" name="precio" required>
                   
                </div>
           <!-- <div class="options">
			<p>Comprobar ingresos</p>
			<div class="center">
				<input type="checkbox" id="ingresos" class="noneDysplay" value="1"/>
				<label for="ingresos" class="toggle"><span></span></label>    
			</div>
		</div>	
                   
            <div class="options">
			<p>Tiene historial</p>
			<div class="center">
				<input type="checkbox" id="historial" class="noneDysplay" value="2"/>
				<label for="historial" class="toggle"><span></span></label>    
			</div>
		   </div>-->
                 <div class="form-group">
                     <button type="submit"  class="button red">
   Realizar cotización
 </button>
                  <!--<a class="button red" href="#">Realizar cotización.</a>-->
                </div>
              </form>
                <a href="/images/INFORMACIÓN SOBRE FINANCIAMIENTOS.pdf" target="_blank">Requisitos para el financiamiento</a>
                <p>Copia el precio del auto para cotizar</p>
               <!-- <h4>Financiación</h4>
<p>Cálculo de mensualidades:</p>
<p id="mensualidad12"></p>
<p id="mensualidad24"></p>
<p id="mensualidad36"></p>
<p id="mensualidad48"></p>-->

            </div> 
          </div>
        </div>
       </div>
     </div>
</section>

<!--=================================
car-details -->
 
 
<!--=================================
 footer -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Auto_Line\Auto_Line\resources\views//principal/vehiculo.blade.php ENDPATH**/ ?>