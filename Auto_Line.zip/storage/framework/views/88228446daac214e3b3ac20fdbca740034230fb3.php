<h2>Nombre Completo: <?php echo e($nombre); ?> <?php echo e($paterno); ?> <?php echo e($materno); ?></h2>
<h2>Email: <?php echo e($correo); ?></h2>
<h2>Télefono: <?php echo e($telefono); ?></h2>
<h2>Nombre del auto:<?php echo e($auto); ?></h2>
<h2>Precio del auto:<?php echo e($precio); ?></h2>
<?php /**PATH C:\xampp\htdocs\Auto_Line\Auto_Line\resources\views//principal/correo_cotizar.blade.php ENDPATH**/ ?>